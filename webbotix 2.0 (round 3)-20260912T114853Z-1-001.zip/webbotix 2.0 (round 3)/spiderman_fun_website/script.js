const rogueSets = [
  {
    tag: "Iconic trouble",
    title: "THE CLASSICS",
    copy: "The villains who made every rooftop feel like a final boss.",
    items: ["Green Goblin", "Doctor Octopus", "Venom"],
  },
  {
    tag: "Unpredictable energy",
    title: "THE WILDCARDS",
    copy: "Not evil by the numbers. That is what makes them dangerous.",
    items: ["Black Cat", "Prowler", "Mysterio"],
  },
  {
    tag: "Across dimensions",
    title: "THE NEW WEB",
    copy: "Different masks. Same impossible responsibility.",
    items: ["Miles Morales", "Gwen Stacy", "Miguel O’Hara"],
  },
];

const eras = [
  { year: "1962", name: "The Early Days", desc: "The first appearance, the first leap, the first time a teenager had to carry a city on his back.", color: "red" },
  { year: "1994", name: "The Clone Saga", desc: "Identity gets complicated. Ben Reilly enters the chat. The web gets wonderfully tangled.", color: "blue" },
  { year: "2014", name: "Spider-Verse", desc: "One spider is a symbol. Many spiders are a movement.", color: "gold" },
];

const questions = [
  { question: "What was Peter Parker’s first instinct after the spider bite?", options: ["Hide it forever", "Test his new abilities", "Tell Aunt May immediately"], answer: 1 },
  { question: "Which borough does Peter call home?", options: ["Queens", "Brooklyn", "The Bronx"], answer: 0 },
  { question: "What does the spider-sense actually do?", options: ["Predict the future", "Warn of danger", "Boost web fluid"], answer: 1 },
];

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

// Mobile navigation
const menuButton = $("#menu-button");
const siteNav = $("#site-nav");
menuButton.addEventListener("click", () => {
  const open = siteNav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(open));
  menuButton.setAttribute("aria-label", open ? "Close menu" : "Open menu");
});
$$(".site-nav a").forEach((link) => link.addEventListener("click", () => {
  siteNav.classList.remove("open");
  menuButton.setAttribute("aria-expanded", "false");
  menuButton.setAttribute("aria-label", "Open menu");
}));

// Rogue category tabs
function renderRogues(index) {
  const set = rogueSets[index];
  $("#rogue-tag").textContent = set.tag;
  $("#rogue-title").textContent = set.title;
  $("#rogue-copy").textContent = set.copy;
  $("#rogue-items").innerHTML = set.items.map((item, itemIndex) =>
    `<span class="rogue-item"><i>${itemIndex + 1}</i>${item}</span>`
  ).join("");
  $$(".rogue-tab").forEach((tab, tabIndex) => {
    const active = tabIndex === index;
    tab.classList.toggle("active", active);
    tab.setAttribute("aria-selected", String(active));
  });
}
$$(".rogue-tab").forEach((tab) => tab.addEventListener("click", () => renderRogues(Number(tab.dataset.rogue))));
renderRogues(0);

// Timeline era selector
$("#era-grid").innerHTML = eras.map((era, index) => `
  <button class="era ${index === 0 ? "active" : ""}" data-era="${index}" aria-pressed="${index === 0}">
    <span class="era-dot">${era.year}</span>
    <h3>${era.name}</h3>
    <p>${era.desc}</p>
    <span class="era-bar ${era.color}"></span>
  </button>
`).join("");

function selectEra(index) {
  const era = eras[index];
  $$(".era").forEach((button, buttonIndex) => {
    const active = index === buttonIndex;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  $("#selected-year").textContent = era.year;
  $("#selected-desc").textContent = `“${era.desc}”`;
  $(".archive-label").textContent = `Archive note ${String(index + 1).padStart(2, "0")}`;
}
$("#era-grid").addEventListener("click", (event) => {
  const button = event.target.closest("[data-era]");
  if (button) selectEra(Number(button.dataset.era));
});

// Quiz
let quizStep = 0;
let quizScore = 0;
let selectedAnswer = null;

function renderQuiz() {
  const question = questions[quizStep];
  $("#quiz-progress").textContent = `Question ${quizStep + 1} / ${questions.length}`;
  $("#quiz-score").textContent = questions.map((_, index) => index < quizStep ? "●" : index === quizStep ? "●" : "○").join(" ");
  $("#quiz-content").innerHTML = `
    <div class="quiz-content">
      <h3>${question.question}</h3>
      <div class="answer-list">
        ${question.options.map((option, index) => `
          <button class="answer-button" data-answer="${index}">
            <span><small>${String.fromCharCode(65 + index)}</small>${option}</span>
            <b aria-hidden="true"></b>
          </button>
        `).join("")}
      </div>
    </div>
  `;
  $$(".answer-button").forEach((button) => button.addEventListener("click", () => chooseAnswer(Number(button.dataset.answer))));
}

function chooseAnswer(index) {
  if (selectedAnswer !== null) return;
  selectedAnswer = index;
  const correct = questions[quizStep].answer;
  if (index === correct) quizScore += 1;
  $$(".answer-button").forEach((button, buttonIndex) => {
    if (buttonIndex === correct) {
      button.classList.add("correct");
      button.querySelector("b").textContent = "✓";
    } else if (buttonIndex === index) {
      button.classList.add("wrong");
      button.querySelector("b").textContent = "×";
    }
  });
  const nextButton = document.createElement("button");
  nextButton.className = "next-button";
  nextButton.textContent = quizStep === questions.length - 1 ? "See results →" : "Next question →";
  nextButton.addEventListener("click", () => {
    if (quizStep === questions.length - 1) showResults();
    else {
      quizStep += 1;
      selectedAnswer = null;
      renderQuiz();
    }
  });
  $("#quiz-content").append(nextButton);
}

function showResults() {
  $("#quiz-progress").textContent = "Results";
  $("#quiz-score").textContent = `${quizScore} correct`;
  $("#quiz-content").innerHTML = `
    <div class="quiz-result">
      <span class="result-check">✓</span>
      <h3>NICE WORK.</h3>
      <p>You got ${quizScore} of ${questions.length}. The city could use you on patrol.</p>
      <button class="reset-button" id="reset-quiz">↻ Run it back</button>
    </div>
  `;
  $("#reset-quiz").addEventListener("click", () => {
    quizStep = 0;
    quizScore = 0;
    selectedAnswer = null;
    renderQuiz();
  });
}
renderQuiz();

// Dispatch controls
$("#subscribe-button").addEventListener("click", () => {
  const button = $("#subscribe-button");
  const subscribed = button.dataset.subscribed === "true";
  button.dataset.subscribed = String(!subscribed);
  button.innerHTML = subscribed ? "Join the dispatch <span>→</span>" : "You are on the list <span>✓</span>";
});
$("#save-button").addEventListener("click", () => {
  const button = $("#save-button");
  const saved = button.dataset.saved === "true";
  button.dataset.saved = String(!saved);
  button.innerHTML = saved ? "♡ <span>Save this issue</span>" : "♥ <span>Saved to your web</span>";
});

// Scroll reveal
const revealObserver = new IntersectionObserver((entries, observer) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
$$(".reveal").forEach((element) => revealObserver.observe(element));